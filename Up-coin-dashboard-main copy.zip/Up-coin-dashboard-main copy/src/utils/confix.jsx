export const baseUrl = "https://pool-vine-backend.herokuapp.com";
export const ClientBaseURL = "https://stakedis.netlify.app/";
